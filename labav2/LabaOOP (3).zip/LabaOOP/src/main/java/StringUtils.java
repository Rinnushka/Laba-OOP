public class StringUtils {
    public static boolean stringIsNullOrEmpty(String str){
        return str == null || str.isEmpty();
    }
}
